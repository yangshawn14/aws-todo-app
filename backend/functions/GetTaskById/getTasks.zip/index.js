const AWS = require('aws-sdk');
const dynamo = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
    const params = {
        TableName: 'ToDoTable',
    };

    try {
        const data = await dynamo.scan(params).promise();
        console.log('DynamoDB Response:', JSON.stringify(data));

        return {
            statusCode: 200,
            body: JSON.stringify(data.Items),
        };
    } catch (error) {
        console.error('Error fetching data:', error);

        return {
            statusCode: 500,
            body: JSON.stringify({
                message: 'Error fetching tasks',
                error
            }),
        };
    }
};