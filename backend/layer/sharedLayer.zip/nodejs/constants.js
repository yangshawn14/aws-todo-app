module.exports = {
    TABLE_NAME: 'ToDoTable',
};